currentPath="$PWD"/../.. &&
$currentPath/cordova/build &&
cp $currentPath/bin/farolas-debug.apk /home/monty/Desktop/aaaaaa.apk